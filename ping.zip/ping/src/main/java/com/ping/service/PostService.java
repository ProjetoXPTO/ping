/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ping.service;

import com.ping.model.Post;
import com.ping.repository.PostRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author dgomes
 */
@Service
public class PostService {
     
    @Autowired
    private PostRepository repository;
     
    public List<Post> findAll() {
        return repository.findAll();
    }
     
    public Post findOne(Long id) {
        return repository.findOne(id);
    }
     
    public Post save(Post post) {
        return repository.saveAndFlush(post);
    }
     
    public void delete(Long id) {
        repository.delete(id);
    }
}
